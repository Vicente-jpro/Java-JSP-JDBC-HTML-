package model;

import java.time.LocalDate;


public class Filme extends Genero {

    private int pk_filme, duracao;
    private String titulo;
    private LocalDate ano_realizado;
    private Pais pais;
    private Realizador realizador;
    private int ano;

    public Filme() {
        pais = new Pais();
        realizador = new Realizador();
        this.pk_filme = 0;
        this.duracao = 0;
        this.titulo = "Não definido";
        this.ano_realizado = LocalDate.parse((CharSequence) "1999-01-01");;
    }

    public Filme(int pk_filme, int duracao, String titulo, LocalDate ano_realizado) {

        this.pk_filme = pk_filme;
        this.duracao = duracao;
        this.titulo = titulo;
        this.ano_realizado = ano_realizado;
    }

    public Filme(int duracao, String titulo, LocalDate ano_realizado) {

        this.pk_filme = 0;
        this.duracao = duracao;
        this.titulo = titulo;
        this.ano_realizado = ano_realizado;
    }

    public Filme(LocalDate ano_realizado) {

        this.pk_filme = 0;
        this.duracao = 0;
        this.titulo = "não definido";
        this.ano_realizado = ano_realizado;
    }

    public Filme(int pk_filme) {

        this.pk_filme = pk_filme;
        this.duracao = 0;
        this.titulo = "não definido";
        this.ano_realizado = LocalDate.parse((CharSequence) "1999-01-01");;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getPk_filme() {
        return pk_filme;
    }

    public void setPk_filme(int pk_filme) {
        this.pk_filme = pk_filme;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate getAno_realizado() {
        return ano_realizado;
    }

    public void setAno_realizado(LocalDate ano_realizado) {
        this.ano_realizado = ano_realizado;
    }

    public Pais getPais() {
        return pais;
    }

    public void setPais(Pais pais) {
        this.pais = pais;
    }

    public Realizador getRealizador() {
        return realizador;
    }

    public void setRealizador(Realizador realizador) {
        this.realizador = realizador;
    }

}
