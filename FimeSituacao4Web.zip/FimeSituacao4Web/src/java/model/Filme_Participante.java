package model;

import java.time.LocalDate;

import model.Autor;
import model.Filme;

public class Filme_Participante {
	
	private Autor autor;
	private Filme filme;
	private LocalDate data_cadastro;
	
	public Filme_Participante() {
		autor = new Autor();
		filme = new Filme();
		this.data_cadastro = LocalDate.parse( (CharSequence) "1999-01-01" );  // Não eliminar essa atribuição
	
	}
	

	public Filme_Participante(Autor autor, Filme filme, LocalDate data_cadastro) {
		super();
		this.autor = autor;
		this.filme = filme;
		this.data_cadastro = data_cadastro;
	}




	public Autor getAutor() {
		return autor;
	}




	public void setAutor(Autor autor) {
		this.autor = autor;
	}




	public Filme getFilme() {
		return filme;
	}




	public void setFilme(Filme filme) {
		this.filme = filme;
	}




	public LocalDate getData_cadastro() {
		return data_cadastro;
	}

	public void setData_cadastro(LocalDate data_cadastro) {
		this.data_cadastro = data_cadastro;
	}

	
	

}
