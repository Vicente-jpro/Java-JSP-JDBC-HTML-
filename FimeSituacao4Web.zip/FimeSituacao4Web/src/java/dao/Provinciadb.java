package dao;

import model.Provincia;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Pais;

public class Provinciadb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Provinciadb() {

		con = ConnectionJDBC.getConnection();

	}

	public List<Provincia> read() {

		String sql = "SELECT nome_provincia FROM provincia";
		List lista = new ArrayList<>();
		Provincia provincia = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				provincia = new Provincia( rs.getString("nome_provincia"));
				lista.add(provincia);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}
	/*
	 * @return Obtem todas as provincias correspondentes 
	 * apartir de um pais. Pelo seu id ou pelo seu nome
	 * */
	public List<Provincia> getCorrespondencia(Pais pais) {

		String sql = "SELECT pk_provincia, nome_provincia \n"
					+ "	FROM public.provincia\n"
					+ "	INNER JOIN pais\n"
					+ "	ON provincia.fk_pais = pais.pk_pais\n"
					+ "	WHERE nome_pais = ' "+pais.getNome_pais()+"'"
					+ " OR pk_pais = "+pais.getPk_pais()+" "
					+ "	ORDER BY nome_provincia";
		
		List lista = new ArrayList<>();
		Provincia provincia = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				provincia = new Provincia( rs.getInt("pk_provincia"), rs.getString("nome_provincia"));
				lista.add(provincia);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}
	

	public Provincia getProvincia (Provincia provincia) {
		
		String sql = " SELECT nome_provincia\n"
				+ "	FROM provincia\n"
				+ "	INNER JOIN pais\n"
				+ "	ON provincia.fk_pais = pais.pk_pais\n"
				+ "	WHERE pk_pais = "+provincia.getPk_provincia()+
				" OR nome_pais = '"+provincia.getNome_provincia()+"'";
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
				provincia = new Provincia(
						rs.getInt("pk_provincia"),
						rs.getString("nome_provincia")
						);
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return provincia;
	}

}
