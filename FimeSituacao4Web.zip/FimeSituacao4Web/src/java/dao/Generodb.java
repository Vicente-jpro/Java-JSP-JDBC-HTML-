package dao;

import model.Genero;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;

public class Generodb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Generodb() {

		con = ConnectionJDBC.getConnection();

	}

	public List<Genero> read() {

		String sql = "SELECT pk_genero, genero FROM genero ";
		List lista = new ArrayList<>();
		Genero genero = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				genero = new Genero(
						rs.getInt("pk_genero"),
						rs.getString("genero")
						);
				lista.add(genero);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Genero getProvincia (Genero genero) {
		
		String sql = " SELECT pk_genero, genero \n"
				+ "	FROM genero \n"
				+ "	WHERE pk_genero = "+genero.getPk_genero();
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
				genero = new Genero(
						rs.getInt("pk_genero"),
						rs.getString("genero")
						);
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return genero;
	}

}
