package uteis;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface OperationSQL {

public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException ;
public void updade(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException ;
public void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException ;
public void read(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException ;
	
		
	
	
}
