package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Bairro;
import model.Bairro;
import model.Pessoa;

public class Bairrodb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Bairrodb() {

		con = ConnectionJDBC.getConnection();

	}

	public void create(Bairro bairro) {

		String sql = "INSERT INTO public.bairro( descricao, fk_municipio) VALUES (?, ?);";

		try {

			stmt = con.prepareStatement(sql);
			stmt.setString(1, bairro.getDescricao());
			stmt.setInt(2, bairro.getPk_municipio());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

	

	public List<Bairro> read() {

		String sql = "SELECT nome_bairro FROM bairro";
		List lista = new ArrayList<>();
		Bairro bairro = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				bairro = new Bairro( rs.getString("nome_bairro"));
				lista.add(bairro);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Bairro getMunicipio (Bairro bairro) {
		
		String sql = " SELECT nome_bairro\n"
				+ "	FROM bairro\n"
				+ "	INNER JOIN municipio\n"
				+ "	ON bairro.fk_municipio = municipio.pk_municipio\n"
				+ "	WHERE pk_bairro = "+bairro.getPk_bairro()+
				" OR nome_municipio = '"+bairro.getNome_municipio()+"'";
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
				bairro = new Bairro(
						rs.getInt("pk_bairro"),
						rs.getString("nome_bairro")
						);
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return bairro;
	}

	

	public int getLastId() {

		String sql = "SELECT pk_bairro"
				+ "	FROM public.bairro";
		
		List<Integer> lista = new ArrayList<Integer>();
		Pessoa pessoa = null;
		
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {
				 
				lista.add( rs.getInt("pk_bairro") );
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista.get( lista.size() - 1 );
	}

	
	
}
