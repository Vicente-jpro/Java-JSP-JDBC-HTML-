package dao;

import model.Realizador;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;

public class Realizadordb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Realizadordb() {

		con = ConnectionJDBC.getConnection();

	}


	

	/*
	 * SELECT pk_realizador, nome_realizador
	FROM public.realizador;
	 * */
	public void create(Realizador realizador) {

		String sql = "INSERT INTO public.realizador( fk_pessoa, data_cadastro)\n"
				+ "	VALUES (?, ?)";

		try {

			stmt = con.prepareStatement(sql);
			stmt.setInt(1, realizador.getPk_pessoa());
			stmt.setObject(2, realizador.getData_cadastro());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}



	public void update(Realizador realizador) {

		String sql = "UPDATE public.realizador\n"
				+ "	SET  fk_pessoa=?, data_cadastro=?\n"
				+ "	WHERE pk_realizador= " + realizador.getPk_realizador();

		try {

			stmt = con.prepareStatement(sql);
			stmt.setInt(1, realizador.getPk_pessoa());
			stmt.setObject(2, realizador.getData_cadastro());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}
		public void delete(Realizador realizador) {

		String sql = "DELETE FROM realizador WHERE pk_realizador = " + realizador.getPk_realizador();

		try {

			stmt = con.prepareStatement(sql);

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

	public List<Realizador> read() {

		String sql = "SELECT pk_realizador, pessoa.nome, realizador.data_cadastro\n"
					+ "	FROM realizador\n"
					+ "	INNER JOIN pessoa\n"
					+ "	ON realizador.fk_pessoa = pessoa.pk_pessoa ORDER BY pk_realizador";
		List lista = new ArrayList<>();
		Realizador realizador = null;
		try {
	
				stmt = con.prepareStatement(sql);
				rs = stmt.executeQuery();
				//rs.last();
				while (rs.next()) {
				
				realizador = new Realizador(
						rs.getInt("pk_realizador"),
						rs.getObject(3, LocalDate.class)
						);
				realizador.setNome( rs.getString("nome") );
					
				lista.add(realizador);
			
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Realizador getRealizador (Realizador realizador) {

		String sql = "SELECT pk_realizador, pessoa.nome, fk_pessoa, realizador.data_cadastro\n"
					+ "	FROM realizador\n"
					+ "	INNER JOIN pessoa\n"
					+ "	ON realizador.fk_pessoa = pessoa.pk_pessoa"
					+ " WHERE  pk_realizador = "+realizador.getPk_realizador();
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
			realizador = new Realizador(
					rs.getInt("pk_realizador"),
					rs.getObject(4, LocalDate.class)
					);
			realizador.setNome( rs.getString("nome") );
			realizador.setPk_pessoa(rs.getInt(  "fk_pessoa" ));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return realizador;
	}
	
	

}
