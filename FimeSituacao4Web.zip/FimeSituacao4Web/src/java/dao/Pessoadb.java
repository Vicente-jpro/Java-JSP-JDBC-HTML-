package dao;

import model.Pessoa;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import jdk.nashorn.internal.runtime.ListAdapter;
import model.Sexo;

public class Pessoadb {

    private PreparedStatement stmt;
    private Connection con;
    private ResultSet rs;

    public Pessoadb() {

        con = ConnectionJDBC.getConnection();

    }

    public void create(Pessoa pessoa) {

        String sql = "INSERT INTO public.pessoa( nome, b_i, data_nascimento,"
                + " data_cadastro, email, telemovel, fk_sexo)\n"
                + "	VALUES ( ?, ?, ?, ?, ?, ?, ?) ";

        try {

            stmt = con.prepareStatement(sql);
            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getB_i());
            stmt.setObject(3, pessoa.getData_nascimento());
            stmt.setObject(4, pessoa.getData_cadastro());
            stmt.setString(5, pessoa.getEmail());
            stmt.setString(6, pessoa.getTelemovel());
            stmt.setInt(7, pessoa.getSexo().getPk_sexo());
            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt);
        }

    }

    public void update(Pessoa pessoa) {

        String sql = "UPDATE  pessoa SET  nome = ?, b_i = ?, "
                + " data_nascimento = ?, data_cadastro = ?, email = ?, telemovel = ?, fk_sexo = ?)\n"
                + "	WHERE pk_pessoa = " + pessoa.getPk_pessoa();

        try {

            stmt = con.prepareStatement(sql);

            stmt.setString(1, pessoa.getNome());
            stmt.setObject(2, pessoa.getData_nascimento());
            stmt.setObject(3, pessoa.getData_cadastro());
            stmt.setString(4, pessoa.getEmail());
            stmt.setString(5, pessoa.getTelemovel());
            stmt.setInt(6, pessoa.getSexo().getPk_sexo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt);
        }

    }

    public void delete(Pessoa pessoa) {

        String sql = "DELETE FROM pessoa WHERE pk_pessoa = " + pessoa.getPk_pessoa();

        try {

            stmt = con.prepareStatement(sql);

            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt);
        }

    }

    public int getLastId() {

        String sql = "SELECT pk_pessoa"
                + "	FROM public.pessoa";

        List<Integer> lista = new ArrayList<Integer>();
        Pessoa pessoa = null;

        try {

            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {

                lista.add(rs.getInt("pk_pessoa"));
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return lista.get(lista.size() - 1);
    }

    public List<Pessoa> read() {

        String sql = "SELECT pk_pessoa, nome, b_i, data_nascimento, data_cadastro, \n"
                + "                email, telemovel, sexo.nome_sexo, fk_sexo, pais.nome_pais,\n"
                + "                provincia.nome_provincia, municipio.nome_municipio, bairro.descricao \n"
                + "             	FROM public.pessoa\n"
                + "             	INNER JOIN morada\n"
                + "             	ON pessoa.pk_pessoa = morada.fk_pessoa\n"
                + "				INNER JOIN bairro\n"
                + "             	ON bairro.pk_bairro = morada.fk_bairro\n"
                + "				INNER JOIN municipio \n"
                + "             	ON municipio.pk_municipio = bairro.fk_municipio\n"
                + "				INNER JOIN provincia\n"
                + "             	ON provincia.pk_provincia = municipio.fk_provincia\n"
                + "             	INNER JOIN pais\n"
                + "             	ON pais.pk_pais = provincia.fk_pais\n"
                + "             	INNER JOIN sexo\n"
                + "             	ON sexo.pk_sexo = pessoa.fk_sexo\n"
                + "             	ORDER BY pk_pessoa;";

        List lista = new ArrayList<>();
        Pessoa pessoa = null;

        try {

            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                /*
		
	public Pessoa(int pk_pessoa, String nome, String b_i, String email, String telemovel,
			LocalDate data_nascimento, LocalDate data_cadastro)		
		
                pk_pessoa, nome, pais.nome_pais, provincia.nome_provincia,\n"
                + "	   municipio.nome_municipio, bairro.descricao,\n"
                + "	   b_i, data_nascimento, data_cadastro, email, \n"
                + "	   telemovel, sexo.nome_sexo, fk_sexo \n"
                * */

                pessoa = new Pessoa(
                        rs.getInt("pk_pessoa"),
                        rs.getString("nome"),
                        rs.getString("b_i"),
                        rs.getString("email"),
                        rs.getString("telemovel"),
                        rs.getObject(4, LocalDate.class),
                        rs.getObject(5, LocalDate.class)
                );

                pessoa.setSexo(new Sexo(rs.getObject(8)));
                pessoa.setNome_pais(rs.getString("nome_pais"));
                pessoa.setNome_provincia(rs.getString("nome_provincia"));
                pessoa.setNome_municipio(rs.getString("nome_municipio"));
                pessoa.setDescricao(rs.getString("descricao"));

                lista.add(pessoa);
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return lista;
    }

    public Pessoa getPessoa(Pessoa pessoa) {

        String sql = "SELECT pk_pessoa, nome, b_i, data_nascimento, \n"
                + "		data_cadastro, email, telemovel, fk_sexo \n"
                + "	FROM public.pessoa; ";

        try {

            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            rs.next();
            /**
             * public Pessoa(int pk_pessoa, String nome, String b_i, String
             * email, String telemovel, LocalDate data_nascimento)
             *
             */
            pessoa = new Pessoa(
                    rs.getInt("pk_pessoa"),
                    rs.getString("nome"),
                    rs.getString("b_i"),
                    rs.getString("email"),
                    rs.getString("telemovel"),
                    rs.getObject(4, LocalDate.class),
                    rs.getObject(5, LocalDate.class)
            );
            pessoa.setSexo(new Sexo(rs.getString("fk_sexo")));

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return pessoa;
    }

}
