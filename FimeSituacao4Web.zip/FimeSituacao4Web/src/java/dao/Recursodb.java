package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Autor;
import model.Genero;

public class Recursodb {

    private PreparedStatement stmt;
    private Connection con;
    private ResultSet rs;

    public Recursodb() {

        con = ConnectionJDBC.getConnection();

    }

    public List<Autor> getConsulta(int anoInicial, int anoFinal, int pk_filme, int pk_genero) {

        String sql = "SELECT pessoa.nome\n"
                + "	FROM autor\n"
                + "	INNER JOIN pessoa\n"
                + "	ON pessoa.pk_pessoa = autor.fk_pessoa\n"
                + "	INNER JOIN filme_participante\n"
                + "	ON filme_participante.fk_autor = autor.pk_autor\n"
                + "	INNER JOIN filme\n"
                + "	ON filme.pk_filme = filme_participante.fk_filme\n"
                + "	INNER JOIN genero\n"
                + "	ON genero.pk_genero = filme.fk_genero\n"
                + "	WHERE EXTRACT (YEAR FROM data_nascimento) >= "+anoInicial
                + "	AND EXTRACT (YEAR FROM data_nascimento) <= "+anoFinal
                + "	AND pk_filme = "+pk_filme
                + "	AND pk_genero = "+pk_genero;

        List lista = new ArrayList<>();
        Autor autor = null;
        try {

            stmt = con.prepareStatement(sql);

            rs = stmt.executeQuery();

            while (rs.next()) {

                autor = new Autor();
                autor.setNome(rs.getString("nome"));

                lista.add(autor);

            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return lista;
    }

}
