package model;

public class Sexo {
	
	private int pk_sexo;
	private Object nome_sexo;
	
	

	public Sexo( Object nome_sexo) {

		this.nome_sexo = nome_sexo;
		this.pk_sexo = 0;  // Não eliminar essa atribuição
	}

	public Sexo(int pk_sexo) {
	
		this.pk_sexo = pk_sexo;
		this.nome_sexo = "Não definido"; // Não eliminar essa atribuição
	}

	public Sexo(int pk_sexo, Object nome_sexo) {

		this.pk_sexo = pk_sexo;
		this.nome_sexo = nome_sexo;
	}


	public int getPk_sexo() {
		return pk_sexo;
	}


	public void setPk_sexo(int pk_sexo) {
		this.pk_sexo = pk_sexo;
	}


	public Object getNome_sexo() {
		return nome_sexo;
	}


	public void setNome_sexo(Object nome_sexo) {
		this.nome_sexo = nome_sexo;
	}
	
	

}
