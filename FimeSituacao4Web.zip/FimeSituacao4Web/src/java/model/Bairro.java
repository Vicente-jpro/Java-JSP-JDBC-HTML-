package model;

public class Bairro extends Municipio{
	
	private int pk_bairro;
	private String descricao;
	

	public Bairro( ) {

		this.pk_bairro = 0;  // Não eliminar essa atribuição
		this.descricao = "nao definida";// Não eliminar essa atribuição
	}

	public Bairro( String descricao) {

		this.pk_bairro = 0;  // Não eliminar essa atribuição
		this.descricao = descricao;// Não eliminar essa atribuição
	}

	public Bairro(int pk_bairro) {
	
		this.pk_bairro = pk_bairro;
		this.descricao = "nao definida";// Não eliminar essa atribuição
	}

	

	public Bairro(int pk_bairro, String descricao) {
	
		this.pk_bairro = pk_bairro;
		this.descricao = descricao;
	}

	public int getPk_bairro() {
		return pk_bairro;
	}

	public void setPk_bairro(int pk_bairro) {
		this.pk_bairro = pk_bairro;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}


	
	

}
