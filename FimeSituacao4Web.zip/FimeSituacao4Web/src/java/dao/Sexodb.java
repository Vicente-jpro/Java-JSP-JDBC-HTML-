package dao;

import model.Sexo;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;

public class Sexodb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Sexodb() {

		con = ConnectionJDBC.getConnection();

	}


	

	public List<Sexo> read() {

		String sql = "SELECT nome_sexo FROM sexo";
		List lista = new ArrayList<>();
		Sexo sexo = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				sexo = new Sexo( rs.getObject(2));
				lista.add(sexo);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Sexo getSexo (Sexo sexo) {
		
		String sql = "SELECT pk_sexo, nome_sexo "
				+ " FROM sexo "
				+ " WHERE pk_sexo = "+sexo.getPk_sexo()+"  "
						+ " OR nome_sexo = "+sexo.getNome_sexo();
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
				sexo = new Sexo(
						rs.getInt("pk_sexo"),
						rs.getString("nome_sexo")
						);
				
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return sexo;
	}

}
