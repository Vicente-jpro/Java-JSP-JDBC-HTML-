package controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Autor;
import model.Filme;
import model.Filme_Participante;
import dao.Filme_Participantedb;
import model.Realizador;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class Filme_ParticipanteController
 */
@WebServlet("/Filme_ParticipanteController")
public class Filme_ParticipanteController extends HttpServlet implements OperationSQL, PageRedirect{
	private static final long serialVersionUID = 1L;
	private static final String FILME_PARTICIPACAO_FORM = "filme_participacao_form.jsp";
	private static final String FILME_PARTICIPACAO_VIEW = "filme_participacao_view.jsp";
	private Filme_Participante filme;
	private Filme_Participantedb filmedb;
	
	private String page ;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Filme_ParticipanteController() {
        super();
        this.page = null;
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		
		String action = request.getParameter("action");
		int pk_autor = 0;
		filmedb = new Filme_Participantedb();
	
		switch(action) {
	
		case "edit": 
		//	updade(request, response);
			this.page = FILME_PARTICIPACAO_FORM;
			
			break;
		case "delete": 
			delete(request, response);
			this.page = FILME_PARTICIPACAO_VIEW;
			break;
		
		case "filme_participacao_view": 
			this.page = FILME_PARTICIPACAO_VIEW;
			break;
		case "filme_participacao_form":
			this.page = FILME_PARTICIPACAO_FORM;

			break;
		default: break;
		
		}
		
		redirect(request, response, page);

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		create(request, response);
		redirect(request, response, FILME_PARTICIPACAO_VIEW);
	}

	@Override
	public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
			throws ServletException, IOException {
		RequestDispatcher view = request.getRequestDispatcher(srcPage);
		view.forward(request, response);
	}

	@Override
	public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String data = request.getParameter("data_participacao");
		String idAutor = request.getParameter("pk_autor"); // Metodo Gett
		int pk_autor = Integer.parseInt( request.getParameter("autor") );
		int pk_filme = Integer.parseInt( request.getParameter( "filme" ) ); 
		
		LocalDate data_participacao = LocalDate.parse( (CharSequence) data);
		
		filme = new Filme_Participante();
		filme.setAutor( new Autor(pk_autor) );
		filme.setFilme( new Filme(pk_filme));
		filme.setData_cadastro(data_participacao);
		
		filmedb = new Filme_Participantedb();
		
		

		// Salvar
		if ( idAutor == null)
			filmedb.create(filme);
		else {
			// Actualizar
			//filme.setPk_filme( Integer.parseInt( pk_autor ));
			filmedb.update(filme);
			
		}
		
		
	}

	@Override
	public void updade(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int pk_autor = Integer.parseInt( request.getParameter("pk_autor") );
		filme = new Filme_Participante();
		filme.setAutor( new Autor(pk_autor));
		filmedb.delete(filme);
		
	}

	@Override
	public void read(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
