package controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Realizador;
import dao.Realizadordb;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class RealizadorController
 */
@WebServlet("/RealizadorController")
public class RealizadorController extends HttpServlet implements OperationSQL, PageRedirect{
	private static final long serialVersionUID = 1L;
	private static final String REALIZADOR_VIEW = "realizador_view.jsp";
	private static final String REALIZADOR_FORM = "realizador_form.jsp";
	private String page;
	private Realizadordb realizadordb;
	private Realizador realizador;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RealizadorController() {
        super();
        this.page = null;
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		int pk_realizador = 0;
		realizadordb = new Realizadordb();
	
		switch(action) {
	
		case "edit": 
		//	updade(request, response);
			this.page = REALIZADOR_FORM;
			
			break;
		case "delete": 
			delete(request, response);
			this.page = REALIZADOR_VIEW;
			break;
		
		case "realizador_view": 
			this.page = REALIZADOR_VIEW;
			break;
		case "realizador_form":
			this.page = REALIZADOR_FORM;

			break;
		default: break;
		
		}
		
		redirect(request, response, page);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		page = REALIZADOR_VIEW;

		String pk_realizador = request.getParameter("pk_realizador");
		String data = request.getParameter("data_cadastro").trim();
		int pk_pessoa = Integer.parseInt( request.getParameter("pessoa"));
		
		LocalDate data_cadastro = LocalDate.parse( (CharSequence) data);

		realizadordb = new Realizadordb();
		realizador = new Realizador(data_cadastro);
		realizador.setPk_pessoa(pk_pessoa);
		
		// Salvar
		if ( pk_realizador == null)
			realizadordb.create(realizador);
		else {
			// Actualizar
			realizador.setPk_realizador( Integer.parseInt( pk_realizador ));
			realizadordb.update(realizador);
			
		}
		
		response.sendRedirect( page );
		
	}

	@Override
	public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
			throws ServletException, IOException {

		RequestDispatcher view = request.getRequestDispatcher(srcPage);
		view.forward(request, response);
		
	}

	@Override
	public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updade(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int pk_realizador = Integer.parseInt( request.getParameter("pk_realizador") );
		realizadordb.delete( new Realizador(pk_realizador) );
		
	}

	@Override
	public void read(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
