package controller;

import model.Autor;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Filme;
import dao.Filme_Consultadb;
import java.util.List;
import model.Pais;
import model.Realizador;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class FilmeController
 */
@WebServlet("/FilmeConsultaController")
public class FilmeConsultaController extends HttpServlet implements OperationSQL, PageRedirect {

    private static final long serialVersionUID = 1L;
    private static final String FILME_VIEW_CCONSULTA = "filme_view_consulta.jsp";
    private static final String FILME_FORM_CCONSULTA = "filme_form_consulta.jsp";
    private String page;
    private Filme filme;
    private Autor auto;
    private Filme_Consultadb filmedb;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public FilmeConsultaController() {

        this.page = null;

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        create(request, response);
        

    }

    @Override
    public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String mensagem = "";
        String film = request.getParameter("filme").trim();
        String ano = request.getParameter("ano");
        String realizador = request.getParameter("realizador");
        String autor = request.getParameter("autor");
        String genero = request.getParameter("genero");
        String pais = request.getParameter("pais");

        System.out.println("Variaveis do html ");
        System.out.println("Ano : " + ano);
        System.out.println("Titulo: " + filme);
        System.out.println("Genero: " + genero);
        System.out.println("Pais: " + pais);
        System.out.println("Autor: " + autor);
        System.out.println("Realizador: " + realizador);

        filme = new Filme();
        auto = new Autor();
        filmedb = new Filme_Consultadb();

        int pk_realizador = 0,
                pk_autor = 0,
                pk_genero = 0,
                pk_pais = 0;

        try {

            if (!film.equalsIgnoreCase("0")) {
                filme.setPk_filme(Integer.parseInt(film));
            } else if (!ano.equalsIgnoreCase("0")) {
                filme.setAno(Integer.parseInt(ano));
                System.out.println("Entrou no if do ano " + ano);
            } else if (!realizador.equalsIgnoreCase("0")) {
                pk_realizador = Integer.parseInt(realizador);
                filme.setRealizador(new Realizador(pk_realizador));
            } else if (!autor.equalsIgnoreCase("0")) {
                pk_autor = Integer.parseInt(autor);
                auto.setPk_autor(pk_autor);
            } else if (!genero.equalsIgnoreCase("0")) {
                pk_genero = Integer.parseInt(genero);
                filme.setPk_genero(pk_genero);
            } else if (!pais.equalsIgnoreCase("0")) {
                pk_pais = Integer.parseInt(pais);
                filme.setPais(new Pais(pk_pais));
            }

            List<Filme> lista = filmedb.read(filme, auto);
            request.setAttribute("listaConsulta", lista);
            
            redirect(request, response, FILME_VIEW_CCONSULTA);
        } catch (NumberFormatException | NullPointerException e) {
            mensagem = "Um dos campos foi mal preenchido";
            request.setAttribute("mensagem", mensagem);
            
            redirect(request, response, FILME_FORM_CCONSULTA);
        }
        // Getters
        System.out.println("Ano : " + filme.getAno());
        System.out.println("Titulo: " + filme.getTitulo());
        System.out.println("Genero: " + filme.getPk_genero());
        System.out.println("Pais: " + filme.getPais().getNome_pais());
        System.out.println("Autor: " + auto.getPk_autor());
        System.out.println("Realizador: " + filme.getRealizador().getPk_realizador());

    }

    @Override
    public void updade(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void read(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
            throws ServletException, IOException {

        RequestDispatcher view = request.getRequestDispatcher(srcPage);
        view.forward(request, response);

    }

}
