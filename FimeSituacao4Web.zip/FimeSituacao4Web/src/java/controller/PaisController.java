package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Pais;
import dao.Paisdb;

/**
 * Servlet implementation class PaisController
 */
@WebServlet("/PaisController")
public class PaisController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String LISTA_PAISES = "lista_paises.jsp";
	private static final String FORM_PAIS = "form_pais.jsp";
    private Pais pais;
    private Paisdb paisdb;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaisController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");
		String page = null;
		switch(action) {
			
		case "edit": break;
		case "visualizar_paises": 
			page = LISTA_PAISES;

			break;
			
		case "delete": break;
		
		
		default: 
			
			break;
		
		}

		paisdb = new Paisdb();
		List<Pais> list = paisdb.read();
		request.setAttribute("listaPaises", list);
		
		RequestDispatcher view = request.getRequestDispatcher(page);
		view.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String nome_pais = request.getParameter("nome_pais");
		
		String page = null;
		
		page = LISTA_PAISES;
		pais = new Pais(nome_pais);
		
		paisdb = new Paisdb();
		paisdb.create(pais);
		
		RequestDispatcher view = request.getRequestDispatcher(page);
		view.forward(request, response);
		
		
		
	}
	


}
