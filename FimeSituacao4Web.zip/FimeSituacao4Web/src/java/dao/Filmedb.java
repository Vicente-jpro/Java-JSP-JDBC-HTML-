package dao;

import model.Filme;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Pais;
import model.Pessoa;
import model.Realizador;
import model.Sexo;

public class Filmedb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Filmedb() {

		con = ConnectionJDBC.getConnection();

	}


	public void create(Filme filme) {

		String sql = "INSERT INTO public.filme( titulo, duracao, ano_realizado, "
				+ " fk_genero, fk_pais, fk_realizador)\n"
				+ "	VALUES ( ?, ?, ?, ?, ?, ?);";

		try {

			stmt = con.prepareStatement(sql);
			stmt.setString(1, filme.getTitulo());
			stmt.setInt(2, filme.getDuracao());
			stmt.setObject(3, filme.getAno_realizado());
			stmt.setInt(4, filme.getPk_genero());
			stmt.setInt(5, filme.getPais().getPk_pais());
			stmt.setInt(6, filme.getRealizador().getPk_realizador());
			
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}


	public void update(Filme filme) {

		String sql = "UPDATE public.filme\n"
				+ "	SET titulo=?, duracao=?, "
				+ " ano_realizado=?, fk_genero=?, fk_pais=?\n"
				+ "	WHERE pk_filme= "+filme.getPk_filme();

		try {

			stmt = con.prepareStatement(sql);

			stmt.setString(1, filme.getTitulo());
			stmt.setInt(2, filme.getDuracao());
			stmt.setObject(3, filme.getAno_realizado());
			stmt.setInt(4, filme.getPk_genero());
			stmt.setInt(5, filme.getPais().getPk_pais());
			
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

		public void delete(Filme filme) {

		String sql = "DELETE FROM filme WHERE pk_filme = " + filme.getPk_filme();

		try {

			stmt = con.prepareStatement(sql);

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

	public List<Filme> read() {

		String sql = "	SELECT pk_filme, titulo, duracao, ano_realizado, \n"
				+ "				genero.genero, pais.nome_pais, pessoa.nome\n"
				+ "				FROM public.filme\n"
				+ "				INNER JOIN genero\n"
				+ "				ON filme.fk_genero = genero.pk_genero\n"
				+ "				INNER JOIN realizador\n"
				+ "				ON filme.fk_realizador = realizador.pk_realizador\n"
				+ "				INNER JOIN pessoa\n"
				+ "				ON realizador.fk_pessoa = pessoa.pk_pessoa\n"
				+ "				INNER JOIN pais\n"
				+ "				ON filme.fk_pais = pais.pk_pais ;";
		
		List lista = new ArrayList<>();
		Filme filme = null;
		
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {
				/*
				 * Filme(int pk_filme, int duracao, String titulo, LocalDate ano_realizado)
				 * */
				filme = new Filme(
						rs.getInt("pk_filme"), 
						rs.getInt("duracao"),
						rs.getString("titulo"),
						rs.getObject(4, LocalDate.class)
						);
				filme.setGenero( rs.getString("genero"));
				filme.setPais( new Pais(rs.getString("nome_pais")) );
				
				Realizador realizador = new Realizador();
				realizador.setNome( rs.getString("nome") );
				filme.setRealizador(realizador);
				
				lista.add(filme);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}


	
	public Filme getFilme(Filme filme) {

		String sql = "SELECT pk_filme, titulo, duracao, ano_realizado, \n"
				+ "	fk_genero, fk_pais, genero.genero, pessoa.nome, \n"
				+ "	realizador.nome, pais.nome_pais\n"
				+ "	FROM public.filme\n"
				+ "	INNER JOIN genero\n"
				+ "	ON filme.fk_genero = genero.pk_genero\n"
				+ "	INNER JOIN realizador\n"
				+ "	ON filme.fk_realizador = realizador.pk_realizador\n"
				+ "	INNER JOIN pais\n"
				+ "	ON filme.fk_pais = pais.pk_pais \n"
				+ "	INNER JOIN pessoa \n"
				+ "	ON filme.fk_realizador = realizador.pk_realizador \n"
				+ "	OR pessoa.pk_pessoa = realizador.fk_pessoa"
				+ "	WHERE pk_filme = "+filme.getPk_filme();
		
		filme = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {
				/*
				 * Filme(int pk_filme, int duracao, String titulo, LocalDate ano_realizado)
				 * */
				filme = new Filme(
						rs.getInt("pk_filme"), 
						rs.getInt("duracao"),
						rs.getString("titulo"),
						rs.getObject(4, LocalDate.class)
						);
				filme.setGenero( rs.getString("genero"));
				filme.setPais( new Pais(rs.getString("nome_pais")) );
				
				filme.setPk_genero(rs.getInt("pk_genero"));
				filme.setPais( new Pais(rs.getInt("pk_pais")) );
				Realizador realizador = new Realizador();
				realizador.setNome(rs.getString("nome"));
				filme.setRealizador( realizador );
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return filme;
	}

	
}
