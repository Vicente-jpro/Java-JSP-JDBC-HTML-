package dao;

import model.Filme;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Autor;
import model.Pais;
import model.Realizador;

public class Filme_Consultadb {

    private PreparedStatement stmt;
    private Connection con;
    private ResultSet rs;

    public Filme_Consultadb() {

        con = ConnectionJDBC.getConnection();

    }

    public List<Filme> read(Filme filme, Autor autor) {

        String sql = "SELECT  titulo, duracao\n"
                + "	FROM public.filme\n"
                + "	INNER JOIN genero\n"
                + "	ON genero.pk_genero = filme.fk_genero\n"
                + "	INNER JOIN pais\n"
                + "	ON pais.pk_pais = filme.fk_pais\n"
                + "	INNER JOIN realizador\n"
                + "	ON realizador.pk_realizador = filme.fk_realizador\n"
                + "	INNER JOIN pessoa\n"
                + "	ON pessoa.pk_pessoa = realizador.fk_pessoa\n"
                + "	INNER JOIN filme_participante\n"
                + "	ON filme_participante.fk_filme = filme.pk_filme\n"
                + "	INNER JOIN autor\n"
                + "	ON autor.pk_autor = filme_participante.fk_autor\n"
                + "	WHERE EXTRACT('YEAR' FROM ano_realizado) = ? \n"
                + "	OR pk_filme = ? "
                + "     OR pk_genero = ? "
                + "	OR pk_pais = ? "
                + "     OR pk_autor = ?"
                + "     OR pk_realizador = ? ";

        System.out.println("Ano na classe db "+filme.getAno());
        List lista = new ArrayList<>();

        try {

            stmt = con.prepareStatement(sql);

            
            
            
            
            stmt.setInt(1, filme.getAno());
            stmt.setInt(2, filme.getPk_filme());
            stmt.setInt(3, filme.getPk_genero());
            stmt.setInt(4, filme.getPais().getPk_pais());
            stmt.setInt(5, autor.getPk_autor());
            stmt.setInt(6, filme.getRealizador().getPk_realizador());

            rs = stmt.executeQuery();

            while (rs.next()) {
                /*
				 * Filme(int pk_filme, int duracao, String titulo, LocalDate ano_realizado)
				 * */
                filme = new Filme();
                
                      filme.setDuracao( rs.getInt("duracao") );  
                        filme.setTitulo(rs.getString("titulo"));

                lista.add(filme);
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return lista;
    }

    public Filme getFilme(Filme filme) {

        String sql = "SELECT pk_filme, titulo, duracao, ano_realizado, \n"
                + "	fk_genero, fk_pais, genero.genero, pessoa.nome, \n"
                + "	realizador.nome, pais.nome_pais\n"
                + "	FROM public.filme\n"
                + "	INNER JOIN genero\n"
                + "	ON filme.fk_genero = genero.pk_genero\n"
                + "	INNER JOIN realizador\n"
                + "	ON filme.fk_realizador = realizador.pk_realizador\n"
                + "	INNER JOIN pais\n"
                + "	ON filme.fk_pais = pais.pk_pais \n"
                + "	INNER JOIN pessoa \n"
                + "	ON filme.fk_realizador = realizador.pk_realizador \n"
                + "	OR pessoa.pk_pessoa = realizador.fk_pessoa"
                + "	WHERE pk_filme = " + filme.getPk_filme();

        filme = null;
        try {

            stmt = con.prepareStatement(sql);

            rs = stmt.executeQuery();

            while (rs.next()) {
                /*
				 * Filme(int pk_filme, int duracao, String titulo, LocalDate ano_realizado)
				 * */
                filme = new Filme(
                        rs.getInt("pk_filme"),
                        rs.getInt("duracao"),
                        rs.getString("titulo"),
                        rs.getObject(4, LocalDate.class)
                );
                filme.setGenero(rs.getString("genero"));
                filme.setPais(new Pais(rs.getString("nome_pais")));

                filme.setPk_genero(rs.getInt("pk_genero"));
                filme.setPais(new Pais(rs.getInt("pk_pais")));
                Realizador realizador = new Realizador();
                realizador.setNome(rs.getString("nome"));
                filme.setRealizador(realizador);

            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return filme;
    }

}
