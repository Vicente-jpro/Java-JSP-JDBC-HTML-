package model;

import java.time.LocalDate;


public class Autor extends Pessoa{

	private int pk_autor;
	private LocalDate data_cadastro;
	
	public Autor() {
		
		this.pk_autor = 0;
		this.data_cadastro = LocalDate.parse( (CharSequence) "1999-01-01" );  // Não eliminar essa atribuição
	
	}
	
	public Autor(int pk_autor) {
	
		this.pk_autor = pk_autor;
		this.data_cadastro = LocalDate.parse( (CharSequence) "1999-01-01" );   // Não eliminar essa atribuição
	
	}
	
	

	public Autor(int pk_autor, LocalDate data_cadastro) {

		this.pk_autor = pk_autor;
		this.data_cadastro = data_cadastro;
	}

	public Autor( LocalDate data_cadastro) {
		this.pk_autor = 0; // Não eliminar essa atribuição
		this.data_cadastro = data_cadastro;
	}




	public int getPk_autor() {
		return pk_autor;
	}

	public void setPk_autor(int pk_autor) {
		this.pk_autor = pk_autor;
	}

	public LocalDate getData_cadastro() {
		return data_cadastro;
	}

	public void setData_cadastro(LocalDate data_cadastro) {
		this.data_cadastro = data_cadastro;
	}

	
	

}
