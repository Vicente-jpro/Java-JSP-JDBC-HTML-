package dao;

import model.Pais;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;

public class Paisdb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Paisdb() {

		con = ConnectionJDBC.getConnection();

	}


	

	/*
	 * SELECT pk_pais, nome_pais
	FROM public.pais;
	 * */
	public void create(Pais pais) {

		String sql = "INSERT INTO public.pais( nome_pais) VALUES (?);";

		try {

			stmt = con.prepareStatement(sql);
			stmt.setString(1, pais.getNome_pais());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}



	public void update(Pais pais) {

		String sql = "UPDATE pais " + " SET nome_pais = ? " + " WHARE pk_pais = " + pais.getPk_pais();

		try {

			stmt = con.prepareStatement(sql);

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}
		public void delete(Pais pais) {

		String sql = "DELETE FROM pais WHERE pk_pais = " + pais.getPk_pais();

		try {

			stmt = con.prepareStatement(sql);
			stmt.setString(1, pais.getNome_pais());

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

	public List<Pais> read() {

		String sql = "SELECT pk_pais, nome_pais FROM pais";
		List lista = new ArrayList<>();
		Pais pais = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			//rs.last();
			while (rs.next()) {

				pais = new Pais(rs.getInt("pk_pais"), rs.getString("nome_pais"));
				lista.add(pais);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Pais getPais (Pais pais) {
		
		String sql = "SELECT pk_pais, nome_pais "
				+ "	FROM pais "
				+ "	WHERE nome_pais = '"+pais.getNome_pais()+"'"
					  + " pk_pais = "+pais.getPk_pais();
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
			pais = new Pais(
					rs.getInt("pk_pais"),
					rs.getString("nome_pais")
					);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return pais;
	}
	
	

}
