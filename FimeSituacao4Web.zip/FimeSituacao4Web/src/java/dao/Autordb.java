package dao;

import model.Autor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;

public class Autordb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Autordb() {

		con = ConnectionJDBC.getConnection();

	}


	

	/*
	 * SELECT pk_autor, nome_autor
	FROM public.autor;
	 * */
	public void create(Autor autor) {

		String sql = "INSERT INTO public.autor( fk_pessoa, data_cadastro)\n"
				+ "	VALUES (?, ?)";

		try {

			stmt = con.prepareStatement(sql);
			stmt.setInt(1, autor.getPk_pessoa());
			stmt.setObject(2, autor.getData_cadastro());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}



	public void update(Autor autor) {

		String sql = "UPDATE public.autor\n"
				+ "	SET  fk_pessoa=?, data_cadastro=?\n"
				+ "	WHERE pk_autor= " + autor.getPk_autor();

		try {

			stmt = con.prepareStatement(sql);
			stmt.setInt(1, autor.getPk_pessoa());
			stmt.setObject(2, autor.getData_cadastro());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}
		public void delete(Autor autor) {

		String sql = "DELETE FROM autor WHERE pk_autor = " + autor.getPk_autor();

		try {

			stmt = con.prepareStatement(sql);

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
                    
			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

	public List<Autor> read() {

		String sql = "SELECT pk_autor, pessoa.nome, autor.data_cadastro\n"
					+ "	FROM autor\n"
					+ "	INNER JOIN pessoa\n"
					+ "	ON autor.fk_pessoa = pessoa.pk_pessoa ORDER BY pk_autor;";
		List lista = new ArrayList<>();
		Autor autor = null;
		try {
	
				stmt = con.prepareStatement(sql);
				rs = stmt.executeQuery();
				//rs.last();
				while (rs.next()) {
				
				autor = new Autor(
						rs.getInt("pk_autor"),
						rs.getObject(3, LocalDate.class)
						);
				autor.setNome( rs.getString("nome") );
					
				lista.add(autor);
			
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Autor getAutor (Autor autor) {

		String sql = "SELECT pk_autor, pessoa.nome, fk_pessoa, autor.data_cadastro\n"
					+ "	FROM autor\n"
					+ "	INNER JOIN pessoa\n"
					+ "	ON autor.fk_pessoa = pessoa.pk_pessoa"
					+ " WHERE  pk_autor = "+autor.getPk_autor();
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
			autor = new Autor(
					rs.getInt("pk_autor"),
					rs.getObject(4, LocalDate.class)
					);
			autor.setNome( rs.getString("nome") );
			autor.setPk_pessoa(rs.getInt(  "fk_pessoa" ));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return autor;
	}
	
	

}
