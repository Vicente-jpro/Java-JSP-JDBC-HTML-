package model;

public class Municipio extends Provincia{
	
	private int pk_municipio;
	private String nome_municipio;
	

	public Municipio() {

		this.pk_municipio = 0;
		this.nome_municipio = "Não definido";
	}


	public Municipio( String nome_municipio) {

		this.nome_municipio = nome_municipio;
		this.pk_municipio = 0;  // Não eliminar essa atribuição
	}

	public Municipio(int pk_municipio) {
	
		this.pk_municipio = pk_municipio;
		this.nome_municipio = "Não definido";  // Não eliminar essa atribuição
	}

	public Municipio(int pk_municipio, String nome_municipio) {

		this.pk_municipio = pk_municipio;
		this.nome_municipio = nome_municipio;
	}

	public int getPk_municipio() {
		return pk_municipio;
	}

	public void setPk_municipio(int pk_municipio) {
		this.pk_municipio = pk_municipio;
	}

	public String getNome_municipio() {
		return nome_municipio;
	}

	public void setNome_municipio(String nome_municipio) {
		this.nome_municipio = nome_municipio;
	}


	
	

}
