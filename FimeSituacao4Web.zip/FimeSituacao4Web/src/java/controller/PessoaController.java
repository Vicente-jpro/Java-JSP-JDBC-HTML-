package controller;

import dao.Provinciadb;
import model.Provincia;
import dao.Paisdb;
import model.Pais;
import dao.Municipiodb;
import model.Municipio;
import dao.Bairrodb;
import model.Bairro;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.Sexo;
import uteis.CurrentDateAndTime;
import model.Pessoa;
import dao.Pessoadb;
import model.Morada;
import dao.Moradadb;

/**
 * Servlet implementation class AutorController
 */
@WebServlet("/PessoaController")
public class PessoaController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final String PESSOA_FORM_MUNICIPIO = "pessoa_form_municipio.jsp";
    private static final String PESSOA_FORM_PROVINCIA = "pessoa_form_provincia.jsp";
    private static final String PESSOA_FORM_PAIS = "pessoa_form_pais.jsp";
    private static final String PESSOA_VIEW = "pessoa_view.jsp";
    private static final String INDEX = "index.jsp";

    private String page = null;

    private Pessoa pessoa;
    private Pessoadb pessoadb;

    private Pais pais;
    private Paisdb paisdb;

    private Provincia provincia;
    private Provinciadb provinciadb;

    private Municipio municipio;
    private Municipiodb municipiodb;

    private Bairro bairro;
    private Bairrodb bairrodb;

    private Morada endereco;
    private Moradadb enderecodb;

    private CurrentDateAndTime currentDateAndTime;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public PessoaController() {
        super();

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            String salvar = request.getParameter("salvar");

            String nome,
                    b_i,
                    data_nascimento,
                    email,
                    telemovel;

            int pk_pais = 0,
                    pk_provincia = 0,
                    pk_municipio = 0,
                    pk_bairro = 0;

            switch (salvar) {

                case "pessoa_form_pais":

                    this.page = PESSOA_FORM_PROVINCIA;

                    nome = request.getParameter("nome");
                    b_i = request.getParameter("b_i");
                    data_nascimento = request.getParameter("data_nascimento");
                    email = request.getParameter("email");
                    telemovel = request.getParameter("telemovel");
                    int pk_sexo = Integer.parseInt(request.getParameter("sexo"));

                    currentDateAndTime = new CurrentDateAndTime();
                    LocalDate dataNascimento = currentDateAndTime.toLocalDate(data_nascimento);
                    LocalDate dataCadastro = currentDateAndTime.getCurrentDate();

                    pessoa = new Pessoa(nome, b_i, email, telemovel, dataNascimento, dataCadastro);

                    pessoa.setSexo(new Sexo(pk_sexo));

                    pessoadb = new Pessoadb();
                    pessoadb.create(pessoa);

                    pk_pais = Integer.parseInt(request.getParameter("pais"));

                    provinciadb = new Provinciadb();
                    List<Provincia> listaP = provinciadb.getCorrespondencia(new Pais(pk_pais));

                    request.setAttribute("listaProvincias", listaP);

                    break;
                case "pessoa_form_provincia":

                    this.page = PESSOA_FORM_MUNICIPIO;

                    pk_provincia = Integer.parseInt(request.getParameter("provincia"));

                    municipiodb = new Municipiodb();
                    List<Municipio> listaM = municipiodb.getCorrespondencia(new Provincia(pk_provincia));

                    request.setAttribute("listaMunicipios", listaM);

                    break;

                case "pessoa_form_municipio":

                    System.out.println("Entrou no case pessoa_form_municipio");
                    page = INDEX;

                    bairrodb = new Bairrodb();
                    bairro = new Bairro();

                    pk_municipio = Integer.parseInt(request.getParameter("municipio"));
                    String descricao = request.getParameter("descricao");

                    System.out.println("ID do municipio  " + pk_municipio);
                    bairro.setDescricao(descricao);
                    bairro.setPk_municipio(pk_municipio);
                    bairrodb.create(bairro);

                    // Salvar a pessoa e os enderecos de forma temporária 
                    bairrodb = new Bairrodb();
                    endereco = new Morada();

                    pk_bairro = bairrodb.getLastId();
                    endereco.setPk_bairro(pk_bairro);
                    
                    System.out.println("Id do bairro "+pk_bairro);
                    System.out.println("Id do bairro "+pk_bairro);
                    System.out.println("Id do bairro "+pk_bairro);

                    pessoadb = new Pessoadb();
                    endereco.setPessoa(new Pessoa(pessoadb.getLastId()));
                    System.out.println("ID da ultima pessoa " + endereco.getPessoa().getPk_pessoa());
                    System.out.println("ID da ultima pessoa " + endereco.getPessoa().getPk_pessoa());
                    System.out.println("ID da ultima pessoa " + endereco.getPessoa().getPk_pessoa());

                    enderecodb = new Moradadb();
                    enderecodb.create(endereco);

                    break;

                default:
                    break;

            }
            System.out.println("Nome da pagina " + page);
            RequestDispatcher view = request.getRequestDispatcher(page);
            view.forward(request, response);

        } catch (DateTimeParseException e) {
            // TODO: handle exception
        }
    }

}
