package controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Autor;
import dao.Autordb;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class AutorController
 */
@WebServlet("/AutorController")
public class AutorController extends HttpServlet implements OperationSQL, PageRedirect {
	private static final long serialVersionUID = 1L;
	private static final String AUTOR_VIEW = "autor_view.jsp";
	private static final String AUTOR_FORM = "autor_form.jsp";
	private String page;
	private Autordb autordb;
	private Autor autor;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AutorController() {
        super();
        this.page = null;
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		int pk_autor = 0;
		autordb = new Autordb();
		
		switch(action) {
	
		case "edit": 
		//	updade(request, response);
			this.page = AUTOR_FORM;
			
			break;
		case "delete": 
			delete(request, response);
			this.page = AUTOR_VIEW;
			break;
		
		case "autor_view": 
			this.page = AUTOR_VIEW;
			break;
		case "autor_form":
			this.page = AUTOR_FORM;

			break;
		default: break;
		
		}
		
		redirect(request, response, page);
		/*
		System.out.println("Nome da pagina  "+page);
		RequestDispatcher view = request.getRequestDispatcher(page);
		view.forward(request, response);
		*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		create(request, response);
		redirect(request, response, AUTOR_VIEW);
		
	}

	@Override
	public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
			throws ServletException, IOException {

		RequestDispatcher view = request.getRequestDispatcher(srcPage);
		view.forward(request, response);
		
	}

	@Override
	public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pk_autor = request.getParameter("pk_autor");
		String data = request.getParameter("data_cadastro").trim();
		int pk_pessoa = Integer.parseInt( request.getParameter("pessoa"));
		
		LocalDate data_cadastro = LocalDate.parse( (CharSequence) data);

		autordb = new Autordb();
		autor = new Autor(data_cadastro);
		autor.setPk_pessoa(pk_pessoa);
		
		// Salvar
		if ( pk_autor == null)
			autordb.create(autor);
		else {
			// Actualizar
			autor.setPk_autor( Integer.parseInt( pk_autor ));
			autordb.update(autor);
			
		}
			
		
	}

	@Override
	public void updade(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int pk_autor = Integer.parseInt( request.getParameter("pk_autor") );
		autor = autordb.getAutor( new Autor(pk_autor));
		request.setAttribute("autor", autor);
		
	}

	@Override
	public void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int pk_autor = Integer.parseInt( request.getParameter("pk_autor") );
		autordb.delete( new Autor(pk_autor) );

	}

	@Override
	public void read(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
