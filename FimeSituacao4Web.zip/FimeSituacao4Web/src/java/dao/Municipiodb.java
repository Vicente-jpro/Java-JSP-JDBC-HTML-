package dao;

import model.Municipio;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Pais;
import model.Pessoa;
import model.Provincia;

public class Municipiodb {

	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Municipiodb() {

		con = ConnectionJDBC.getConnection();

	}


	public List<Municipio> read() {

		String sql = "SELECT nome_municipio FROM municipio";
		List lista = new ArrayList<>();
		Municipio municipio = null;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				municipio = new Municipio( rs.getString("nome_municipio"));
				lista.add(municipio);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Municipio getMunicipio (Municipio municipio) {
		
		String sql = " SELECT nome_municipio\n"
				+ "	FROM municipio\n"
				+ "	INNER JOIN provincia\n"
				+ "	ON municipio.fk_provincia = provincia.pk_provincia\n"
				+ "	WHERE pk_provincia = "+municipio.getPk_municipio()+
				" OR nome_provincia = '"+municipio.getNome_municipio()+"'";
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
				
				municipio = new Municipio(
						rs.getInt("pk_municipio"),
						rs.getString("nome_municipio")
						);
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return municipio;
	}
	
	
	/*
	 * @return Obtem todas as provincias correspondentes 
	 * apartir de um pais. Pelo seu id ou pelo seu nome
	 * */
	public List<Municipio> getCorrespondencia(Provincia provincia) {

		String sql = "SELECT pk_municipio,nome_municipio \n"
					+ "	FROM public.municipio\n"
					+ "	INNER JOIN provincia\n"
					+ "	ON municipio.fk_provincia = provincia.pk_provincia\n"
					+ "	WHERE nome_provincia = '"+provincia.getNome_provincia()+"' "
							+ "OR pk_provincia = "+provincia.getPk_provincia()
					+ "	ORDER BY nome_municipio";
		
		List lista = new ArrayList<>();
		
		Municipio municipio;
		try {

			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {

				municipio = new Municipio( rs.getInt("pk_municipio"), rs.getString("nome_municipio"));
				lista.add(municipio);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}
	
	
	
	
	
	

}
