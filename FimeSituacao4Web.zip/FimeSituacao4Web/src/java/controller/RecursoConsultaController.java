package controller;

import model.Autor;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Filme;
import dao.Filme_Consultadb;
import dao.Recursodb;
import java.util.List;
import model.Realizador;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class FilmeController
 */
@WebServlet("/RecursoConsultaController")
public class RecursoConsultaController extends HttpServlet implements OperationSQL, PageRedirect {

    private static final long serialVersionUID = 1L;
    private static final String RECURSO_VIEW_CCONSULTA = "recurso_view_consulta.jsp";
    private static final String RECURSO_FORM_CCONSULTA = "recurso_form_consulta.jsp";
    private String page;
    private Filme film;
    private Autor auto;
    private Realizador realizado;
    private Recursodb recursodb;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecursoConsultaController() {

        this.page = null;

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        create(request, response);

    }

    @Override
    public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String anoInicial = request.getParameter("anoInicial");
        String anoFinal = request.getParameter("anoFinal");


        String filme = request.getParameter("filme");

        String genero = request.getParameter("genero");
      

        int  pk_genero = Integer.parseInt(genero);
        int pk_filme = Integer.parseInt( filme );
        
        int anoIni = Integer.parseInt( anoInicial );
        int anoFin = Integer.parseInt(anoFinal);
//

        System.out.println("Variaveis do html ");
        System.out.println("Ano Inicial : " + anoIni);
        System.out.println("Ano Final: " + anoFin);
        System.out.println("Genero: " + pk_genero);
        System.out.println("Filme: " + pk_filme);

        recursodb = new Recursodb();
        List<Autor> lista = recursodb.getConsulta(anoIni, anoFin, pk_filme, pk_genero);
        request.setAttribute("listaAutor", lista);
        //  redirect(request, response, RECURSO_VIEW_CCONSULTA);
        redirect(request, response, RECURSO_VIEW_CCONSULTA);

    }

    @Override
    public void updade(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void read(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
            throws ServletException, IOException {

        RequestDispatcher view = request.getRequestDispatcher(srcPage);
        view.forward(request, response);

    }

    public int calcularAno(int idade) {
        return (2021 - idade);

    }

}
