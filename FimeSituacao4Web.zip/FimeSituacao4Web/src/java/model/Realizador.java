package model;

import java.time.LocalDate;

import model.Pessoa;

public class Realizador extends Pessoa{

	private int pk_realizador;
	private LocalDate data_cadastro;
	
	public Realizador() {
		
		this.pk_realizador = 0;
		this.data_cadastro = LocalDate.parse( (CharSequence) "1999-01-01" );  // Não eliminar essa atribuição
	
	}
	
	public Realizador(int pk_realizador) {
	
		this.pk_realizador = pk_realizador;
		this.data_cadastro = LocalDate.parse( (CharSequence) "1999-01-01" );   // Não eliminar essa atribuição
	
	}
	
	

	public Realizador(int pk_realizador, LocalDate data_cadastro) {

		this.pk_realizador = pk_realizador;
		this.data_cadastro = data_cadastro;
	}

	public Realizador( LocalDate data_cadastro) {
		this.pk_realizador = 0; // Não eliminar essa atribuição
		this.data_cadastro = data_cadastro;
	}



	public int getPk_realizador() {
		return pk_realizador;
	}

	public void setPk_realizador(int pk_realizador) {
		this.pk_realizador = pk_realizador;
	}

	public LocalDate getData_cadastro() {
		return data_cadastro;
	}

	public void setData_cadastro(LocalDate data_cadastro) {
		this.data_cadastro = data_cadastro;
	}

	
	

}
