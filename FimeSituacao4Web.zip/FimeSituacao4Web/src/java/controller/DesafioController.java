package controller;

import model.Autor;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Filme;
import dao.Desafio_Consultadb;
import java.time.LocalDate;
import java.util.List;
import model.Pais;
import model.Provincia;
import model.Realizador;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class FilmeController
 */
@WebServlet("/DesafioController")
public class DesafioController extends HttpServlet implements OperationSQL, PageRedirect {

    private static final long serialVersionUID = 1L;
    private static final String DESAFIO_VIEW = "desafio_view.jsp";
    private static final String DESAFIO_FORM = "desafio_form.jsp";
    private String page;
    private Filme filme;
    private Autor autor;
    private Provincia provin;
    private Desafio_Consultadb filmedb;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DesafioController() {

        this.page = null;

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        create(request, response);
        redirect(request, response, DESAFIO_VIEW);

    }

    @Override
    public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String idadeInial = request.getParameter("idadeInicial");
        String idadeFinal = request.getParameter("idadeFinal");
        String filme = request.getParameter("filme");
        
        System.out.println("idade Inicial:  : " + idadeInial);
        System.out.println("idade Final:  " + idadeFinal);
        System.out.println("pk_filme:  " + filme);
        int pk_filme = Integer.parseInt( request.getParameter("filme") );
        int ano_inial = calcularAno( Integer.parseInt(idadeInial) );
        int ano_Final = calcularAno( Integer.parseInt(idadeFinal) );
        
        
        System.out.println("Ano Inicial: " + ano_inial);
        System.out.println("Ano Final:  " + ano_Final);
        System.out.println("pk_filme:  " + filme);
        filmedb = new Desafio_Consultadb();
        List<Autor> lista = filmedb.getConsulta(ano_inial, ano_Final, pk_filme);

        request.setAttribute("listaAutor", lista);

    }

    @Override
    public void updade(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void read(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub

    }

    @Override
    public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
            throws ServletException, IOException {

        RequestDispatcher view = request.getRequestDispatcher(srcPage);
        view.forward(request, response);

    }

    public int calcularAno(int idade) {
        return (2021 - idade);

    }

}
