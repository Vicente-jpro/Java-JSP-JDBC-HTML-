package model;


public class Pais {

	private int pk_pais;
	private String nome_pais;
	
	public Pais() {
		
		this.pk_pais = 0;
		this.nome_pais = "não definido";  // Não eliminar essa atribuição
	
	}
	
	public Pais(int pk_pais) {
	
		this.pk_pais = pk_pais;
		this.nome_pais = "não definido";  // Não eliminar essa atribuição
	
	}
	
	

	public Pais(int pk_pais, String nome_pais) {

		this.pk_pais = pk_pais;
		this.nome_pais = nome_pais;
	}

	public Pais( String nome_pais) {
		this.pk_pais = 0; // Não eliminar essa atribuição
		this.nome_pais = nome_pais;
	}



	public int getPk_pais() {
		return pk_pais;
	}

	public void setPk_pais(int pk_pais) {
		this.pk_pais = pk_pais;
	}

	public String getNome_pais() {
		return nome_pais;
	}

	public void setNome_pais(String nome_pais) {
		this.nome_pais = nome_pais;
	}

	public String toString() { return nome_pais; }
	

}
