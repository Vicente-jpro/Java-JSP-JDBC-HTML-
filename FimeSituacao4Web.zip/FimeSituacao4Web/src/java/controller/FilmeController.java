package controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Filme;
import dao.Filmedb;
import model.Genero;
import model.Pais;
import model.Realizador;
import uteis.OperationSQL;
import uteis.PageRedirect;

/**
 * Servlet implementation class FilmeController
 */
@WebServlet("/FilmeController")
public class FilmeController extends HttpServlet implements OperationSQL, PageRedirect{
	private static final long serialVersionUID = 1L;
    private static final String FILME_FORM = "filme_form.jsp";
    private static final String FILME_VIEW = "filme_view.jsp";
    private String page;
    private Filme filme;
    private Filmedb filmedb ;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FilmeController() {
        
    	this.page = null;
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		create(request, response);
		redirect(request, response, FILME_VIEW);
		
	}

	@Override
	public void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String titulo = request.getParameter("titulo");
		String data = request.getParameter("ano_realizado");
		
		int pk_realizador = Integer.parseInt(request.getParameter("realizador"));
		int duracao = Integer.parseInt(request.getParameter("duracao"));
		int pk_genero = Integer.parseInt(request.getParameter("genero"));
		int pk_pais = Integer.parseInt(request.getParameter("pais"));
		
		LocalDate ano_realizado = LocalDate.parse( (CharSequence) data);
		
		filme = new Filme(duracao, titulo, ano_realizado);
		filme.setRealizador( new Realizador(pk_realizador) );
		filme.setPais( new Pais(pk_pais) );
		filme.setPk_genero(pk_genero);
		
		filmedb = new Filmedb();
		filmedb.create(filme);
		
		
		
	}

	@Override
	public void updade(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void read(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void redirect(HttpServletRequest request, HttpServletResponse response, String srcPage)
			throws ServletException, IOException {
		
		RequestDispatcher view = request.getRequestDispatcher(srcPage);
		view.forward(request, response);
		
	}

}
