package model;

import model.Pais;

public class Provincia extends Pais{
	
	private int pk_provincia;
	private String nome_provincia;
	
	

	public Provincia( ) {

		this.nome_provincia = "Não definido";  // Não eliminar essa atribuição
		this.pk_provincia = 0;  // Não eliminar essa atribuição
	}
	public Provincia( String nome_provincia) {

		this.nome_provincia = nome_provincia;
		this.pk_provincia = 0;  // Não eliminar essa atribuição
	}

	public Provincia(int pk_provincia) {
	
		this.pk_provincia = pk_provincia;
		this.nome_provincia = "Não definido";  // Não eliminar essa atribuição
	}

	public Provincia(int pk_provincia, String nome_provincia) {

		this.pk_provincia = pk_provincia;
		this.nome_provincia = nome_provincia;
	}

	public int getPk_provincia() {
		return pk_provincia;
	}

	public void setPk_provincia(int pk_provincia) {
		this.pk_provincia = pk_provincia;
	}

	public String getNome_provincia() {
		return nome_provincia;
	}

	public void setNome_provincia(String nome_provincia) {
		this.nome_provincia = nome_provincia;
	}





	
	

}
