package model;

public class Genero {
	
	private int pk_genero;
	private String genero;
	
	

	public Genero( ) {

		this.genero = "Não definido";  // Não eliminar essa atribuição
		this.pk_genero = 0;  // Não eliminar essa atribuição
	}
	public Genero( String genero) {

		this.genero = genero;
		this.pk_genero = 0;  // Não eliminar essa atribuição
	}

	public Genero(int pk_genero) {
	
		this.pk_genero = pk_genero;
		this.genero = "Não definido";  // Não eliminar essa atribuição
	}

	public Genero(int pk_genero, String genero) {

		this.pk_genero = pk_genero;
		this.genero = genero;
	}
	public int getPk_genero() {
		return pk_genero;
	}
	public void setPk_genero(int pk_genero) {
		this.pk_genero = pk_genero;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}


	

}
