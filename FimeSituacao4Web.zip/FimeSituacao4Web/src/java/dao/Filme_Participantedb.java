package dao;

import model.Filme_Participante;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Autor;
import model.Filme;

public class Filme_Participantedb {
	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;

	public Filme_Participantedb() {

		con = ConnectionJDBC.getConnection();

	}


	

	/*
	 * SELECT pk_filme_participante, nome_filme_participante
	FROM public.filme_participante;
	 * */
	public void create(Filme_Participante filme_participante) {
		
		String sql = "INSERT INTO public.filme_participante( fk_autor, data_participacao, fk_filme)\n"
				+ "	VALUES (?, ?, ?)";

		try {

			stmt = con.prepareStatement(sql);
			stmt.setInt(1, filme_participante.getAutor().getPk_autor());
			stmt.setObject(2, filme_participante.getData_cadastro());
			stmt.setInt(3, filme_participante.getFilme().getPk_filme());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}



	public void update(Filme_Participante filme_participante) {

		String sql = "UPDATE public.filme_participante\n"
				+ "	SET  fk_autor = ?, data_participacao = ?, fk_filme = ?\n"
				+ "	WHERE fk_filme = " + filme_participante.getFilme().getPk_filme()+" "
				+ " OR fk_autor = "+filme_participante.getAutor().getPk_autor();

		try {

			stmt = con.prepareStatement(sql);
			stmt.setInt(1, filme_participante.getAutor().getPk_autor());
			stmt.setObject(2, filme_participante.getData_cadastro());
			stmt.setInt(3, filme_participante.getFilme().getPk_filme());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}
		public void delete(Filme_Participante filme_participante) {

		String sql = "DELETE FROM filme_participante "
				+ " WHERE fk_filme = " + filme_participante.getFilme().getPk_filme();

		try {

			stmt = con.prepareStatement(sql);

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt);
		}

	}

	public List<Filme_Participante> read() {

		String sql = "SELECT pessoa.nome, filme.titulo, data_participacao, fk_autor, fk_filme\n"
					+ "	FROM public.filme_participante\n"
					+ "	INNER JOIN autor\n"
					+ "	ON filme_participante.fk_autor = autor.pk_autor\n"
					+ "	INNER JOIN filme\n"
					+ "	ON filme_participante.fk_filme = filme.pk_filme\n"
					+ "	INNER JOIN pessoa\n"
					+ "	ON autor.fk_pessoa = pessoa.pk_pessoa  ORDER BY fk_autor";
		
		List lista = new ArrayList<>();
		Filme_Participante filme_participante = null;
		try {
	
				stmt = con.prepareStatement(sql);
				rs = stmt.executeQuery();
				//rs.last();
				while (rs.next()) {
				
				filme_participante = new Filme_Participante();
				filme_participante.setData_cadastro(rs.getObject(3, LocalDate.class));
				Autor autor = new Autor();
				autor.setNome( rs.getString("nome"));
				autor.setPk_autor( rs.getInt("fk_autor"));
				filme_participante.setAutor(autor);
				
				Filme filme = new Filme();
				filme.setTitulo(rs.getString("titulo"));
				filme.setPk_filme( rs.getInt("fk_filme"));
				filme_participante.setFilme(filme);
				
				lista.add(filme_participante);
			
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return lista;
	}

	public Filme_Participante getParticipante (Filme_Participante filme_participante) {

		String sql = "SELECT pessoa.nome, filme.titulo, data_participacao, fk_autor, fk_filme\n"
					+ "	FROM public.filme_participante\n"
					+ "	INNER JOIN autor\n"
					+ "	ON filme_participante.fk_autor = autor.pk_autor\n"
					+ "	INNER JOIN filme\n"
					+ "	ON filme_participante.fk_filme = filme.pk_filme\n"
					+ "	INNER JOIN pessoa\n"
					+ "	ON autor.fk_pessoa = pessoa.pk_pessoa "
					+ " WHERE fk_filme = "+filme_participante.getFilme().getPk_filme()+" "
					+ " OR fk_autor = "+filme_participante.getAutor().getPk_autor();
		
		try {
			
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
			
			filme_participante = new Filme_Participante();
			filme_participante.setData_cadastro(rs.getObject(3, LocalDate.class));
			
			Autor autor = new Autor();
			autor.setNome( rs.getString("nome"));
			autor.setPk_autor( rs.getInt("fk_autor") );
			Filme filme = new Filme();
			filme.setTitulo(rs.getString("titulo"));
			filme.setPk_filme( rs.getInt("fk_filme"));
			
			filme_participante.setAutor(autor);
			filme_participante.setFilme(filme);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			ConnectionJDBC.closeConnection(con, stmt, rs);
		}
		return filme_participante;
	}
	
	

}
