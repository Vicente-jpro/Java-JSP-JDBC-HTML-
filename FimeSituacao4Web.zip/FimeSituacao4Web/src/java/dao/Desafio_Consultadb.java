package dao;

import model.Filme;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import java.time.LocalDate;
import model.Autor;
import model.Pais;
import model.Realizador;

public class Desafio_Consultadb {

    private PreparedStatement stmt;
    private Connection con;
    private ResultSet rs;

    public Desafio_Consultadb() {

        con = ConnectionJDBC.getConnection();

    }

    public List<Autor> getConsulta(int anoInicial, int anoFinal, int pk_filme) {

        String sql = "SELECT pessoa.nome\n"
                + "	FROM autor\n"
                + "	INNER JOIN pessoa\n"
                + "	ON pessoa.pk_pessoa = autor.fk_pessoa\n"
                + "	INNER JOIN filme_participante\n"
                + "	ON filme_participante.fk_autor = autor.pk_autor\n"
                + "	WHERE EXTRACT (YEAR FROM data_nascimento) >= "+anoFinal
                + "	AND EXTRACT (YEAR FROM data_nascimento) <= "+anoFinal
                + "	AND fk_filme = "+pk_filme;

        List lista = new ArrayList<>();
        Autor autor = null;
        try {

            stmt = con.prepareStatement(sql);

            rs = stmt.executeQuery();

            while (rs.next()) {

                autor = new Autor();
                autor.setNome(rs.getString("nome"));

                lista.add(autor);

            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return lista;
    }

}
