package model;

import model.Bairro;
import java.time.LocalDate;

import model.Sexo;

public class Pessoa extends Bairro{

	private int pk_pessoa;
	private Sexo sexo; 
	private String nome, b_i, email, telemovel;
	private LocalDate data_nascimento,
						data_cadastro; 
	
	
	
	public Pessoa() {
		
		this.pk_pessoa = 0;
		this.nome = "Não Definido";
		this.b_i = "Não Definido";
		this.email = "Não Definido";
		this.telemovel = "Não Definido";
		this.data_nascimento = LocalDate.parse( (CharSequence) "1999-01-01");
		this.data_cadastro = LocalDate.parse( (CharSequence) "1999-01-01");
		
	}



	public Pessoa(int pk_pessoa, String nome, String b_i, String email, String telemovel,
			LocalDate data_nascimento, LocalDate data_cadastro) {
		this.pk_pessoa = pk_pessoa;
		this.nome = nome;
		this.b_i = b_i;
		this.email = email;
		this.telemovel = telemovel;
		this.data_nascimento = data_nascimento;
		this.data_cadastro = data_cadastro;
	}
	
	public Pessoa(String nome, String b_i, String email, String telemovel,
			LocalDate data_nascimento, LocalDate data_cadastro) {
		this.pk_pessoa = pk_pessoa;
		this.nome = nome;
		this.b_i = b_i;
		this.email = email;
		this.telemovel = telemovel;
		this.data_nascimento = data_nascimento;
		this.data_cadastro = data_cadastro;
	}
	
	
	public Pessoa(int pk_pessoa, String nome) {
		this.pk_pessoa = pk_pessoa;
		this.nome = nome;
		this.b_i = "Não definido";
		this.email = "Não definido";
		this.telemovel = "Não definido";
		this.data_nascimento = LocalDate.parse( (CharSequence) "1999-01-01");
	}
	public Pessoa( String nome) {
		this.pk_pessoa = 0;
		this.nome = nome;
		this.b_i = "Não definido";
		this.email = "Não definido";
		this.telemovel = "Não definido";
		this.data_nascimento = LocalDate.parse( (CharSequence) "1999-01-01");
	}
	
	public Pessoa(int pk_pessoa ) {
		this.pk_pessoa = pk_pessoa;
		this.nome = "Não definido";
		this.b_i = "Não definido";
		this.email = "Não definido";
		this.telemovel = "Não definido";
		this.data_nascimento = LocalDate.parse( (CharSequence) "1999-01-01");
	}





	public LocalDate getData_cadastro() {
		return data_cadastro;
	}



	public void setData_cadastro(LocalDate data_cadastro) {
		this.data_cadastro = data_cadastro;
	}



	public int getPk_pessoa() {
		return pk_pessoa;
	}



	public void setPk_pessoa(int pk_pessoa) {
		this.pk_pessoa = pk_pessoa;
	}



	public Sexo getSexo() {
		return sexo;
	}



	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getB_i() {
		return b_i;
	}



	public void setB_i(String b_i) {
		this.b_i = b_i;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getTelemovel() {
		return telemovel;
	}



	public void setTelemovel(String telemovel) {
		this.telemovel = telemovel;
	}



	public LocalDate getData_nascimento() {
		return data_nascimento;
	}



	public void setData_nascimento(LocalDate data_nascimento) {
		this.data_nascimento = data_nascimento;
	}
	
	
	

}
