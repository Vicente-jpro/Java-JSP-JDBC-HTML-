package dao;

import model.Morada;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import Connectiondb.ConnectionJDBC;
import model.Pessoa;

public class Moradadb {

    private PreparedStatement stmt;
    private Connection con;
    private ResultSet rs;

    public Moradadb() {

        con = ConnectionJDBC.getConnection();

    }

    /*
	 * SELECT pk_morada, fk_pessoa, fk_pais, fk_provincia, fk_municipio, fk_bairro
	FROM public.morada;
	 * */
    public void create(Morada morada) {

        String sql = "INSERT INTO public.morada "
                + " ( fk_pessoa, fk_bairro) "
                + " VALUES (?, ?) ";

        try {

            stmt = con.prepareStatement(sql);

            stmt.setInt(1, morada.getPessoa().getPk_pessoa());
            stmt.setInt(2, morada.getPk_bairro());
            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt);
        }

    }

    public void update(Morada morada) {

        String sql = "UPDATE morada "
                + " SET fk_bairro = ? "
                + " WHERE fk_pessoa = ?";

        try {

            stmt = con.prepareStatement(sql);
            stmt.setInt(1, morada.getPk_bairro());
            stmt.setInt(2, morada.getPessoa().getPk_pessoa());

            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt);
        }

    }

    public void delete(Morada morada) {

        String sql = "DELETE FROM morada "
                + " WHERE pk_pessoa = " + morada.getPessoa().getPk_pessoa();

        try {

            stmt = con.prepareStatement(sql);
            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt);
        }

    }

    public List<Morada> read() {

        String sql = "SELECT pessoa.nome, pais.nome_pais, provincia.nome_provincia,\n"
                + "	   municipio.nome_municipio, bairro.descricao\n"
                + "	   FROM morada\n"
                + "	   INNER JOIN pessoa\n"
                + "	   ON morada.fk_pessoa = pessoa.pk_pessoa\n"
                + "	   INNER JOIN pais\n"
                + "	   ON morada.fk_pais = pais.pk_pais\n"
                + "	   INNER JOIN provincia\n"
                + "	   ON morada.fk_provincia = provincia.pk_provincia\n"
                + "	   INNER JOIN municipio\n"
                + "	   ON morada.fk_municipio = municipio.pk_municipio\n"
                + "	   INNER JOIN bairro\n"
                + "	   ON morada.fk_bairro = bairro.pk_bairro ";

        List lista = new ArrayList<>();
        Morada pessoa = null;
        try {

            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {

                pessoa = new Morada();
                pessoa.setPessoa(new Pessoa(rs.getString("nome")));
                pessoa.setNome_pais(rs.getString("nome_pais"));
                pessoa.setNome_provincia(rs.getString("nome_provincia"));
                pessoa.setNome_municipio(rs.getString("nome_municipio"));
                pessoa.setDescricao(rs.getString("descricao"));
                lista.add(pessoa);
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return lista;
    }

    public Morada getPessoa_endereco(Morada endereco) {

        String sql = "SELECT pessoa.nome, pais.nome_pais, provincia.nome_provincia,\n"
                + "	   municipio.nome_municipio, bairro.descricao, fk_pessoa, \n"
                + "	   fk_pais, fk_provincia, fk_municipio, fk_bairro\n"
                + "	   FROM morada\n"
                + "	   INNER JOIN pessoa\n"
                + "	   ON morada.fk_pessoa = pessoa.pk_pessoa\n"
                + "	   INNER JOIN pais\n"
                + "	   ON morada.fk_pais = pais.pk_pais\n"
                + "	   INNER JOIN provincia\n"
                + "	   ON morada.fk_provincia = provincia.pk_provincia\n"
                + "	   INNER JOIN municipio\n"
                + "	   ON morada.fk_municipio = municipio.pk_municipio\n"
                + "	   INNER JOIN bairro\n"
                + "	   ON morada.fk_bairro = bairro.pk_bairro\n"
                + "	   WHERE fk_pessoa = " + endereco.getPessoa().getPk_pessoa();

        Morada pessoa = null;
        try {

            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            rs.next();

            pessoa = new Morada();

            pessoa.setPessoa(new Pessoa(rs.getString("nome")));
            pessoa.setNome_pais(rs.getString("nome_pais"));
            pessoa.setNome_provincia(rs.getString("nome_provincia"));
            pessoa.setNome_municipio(rs.getString("nome_municipio"));
            pessoa.setDescricao(rs.getString("descricao"));

            pessoa.setPessoa(new Pessoa(rs.getInt("fk_pessoa")));
            pessoa.setPk_pais(rs.getInt("pk_pais"));
            pessoa.setPk_provincia(rs.getInt("pk_provincia"));
            pessoa.setPk_municipio(rs.getInt("pk_municipio"));
            pessoa.setPk_bairro(rs.getInt("pk_bairro"));

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {

            ConnectionJDBC.closeConnection(con, stmt, rs);
        }
        return pessoa;
    }

}
